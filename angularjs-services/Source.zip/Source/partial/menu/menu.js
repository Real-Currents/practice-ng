angular.module('brew-everywhere').controller('MenuCtrl',function($scope){


});