angular.module('brew-everywhere').controller('ErrorCtrl',function($scope){


});