/*jshint -W117*/
describe('googlePlusAuthentication', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(googlePlusAuthentication) {

	//expect(googlePlusAuthentication.doSomething()).toEqual('something');

  }));

});