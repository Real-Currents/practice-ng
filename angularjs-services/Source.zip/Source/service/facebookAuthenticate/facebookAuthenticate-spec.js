describe('facebookAuthenticate', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(facebookAuthenticate) {

	//expect(facebookAuthenticate.doSomething()).toEqual('something');

  }));

});