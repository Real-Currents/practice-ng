/*jshint -W117*/
describe('notification', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(notification) {

	//expect(notification.doSomething()).toEqual('something');

  }));

});