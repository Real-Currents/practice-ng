describe('waterProfileDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(waterProfileDataService) {

	//expect(waterProfileDataService.doSomething()).toEqual('something');

  }));

});