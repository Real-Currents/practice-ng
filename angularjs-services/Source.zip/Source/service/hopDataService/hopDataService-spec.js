describe('hopDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(hopDataService) {

	//expect(hopDataService.doSomething()).toEqual('something');

  }));

});