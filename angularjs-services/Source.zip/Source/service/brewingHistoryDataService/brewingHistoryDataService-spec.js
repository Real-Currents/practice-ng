describe('brewingHistoryDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(brewingHistoryDataService) {

	//expect(brewingHistoryDataService.doSomething()).toEqual('something');

  }));

});