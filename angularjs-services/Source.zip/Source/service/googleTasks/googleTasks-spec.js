describe('googleTasks', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(googleTasks) {

	//expect(googleTasks.doSomething()).toEqual('something');

  }));

});