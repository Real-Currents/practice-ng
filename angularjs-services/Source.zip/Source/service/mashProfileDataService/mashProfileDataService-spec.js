describe('mashProfileDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(mashProfileDataService) {

	//expect(mashProfileDataService.doSomething()).toEqual('something');

  }));

});