describe('yeastDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(yeastDataService) {

	//expect(yeastDataService.doSomething()).toEqual('something');

  }));

});