/*jshint -W117*/
describe('logging', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(logging) {

	//expect(logging.doSomething()).toEqual('something');

  }));

});