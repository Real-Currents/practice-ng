describe('recipeDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(recipeDataService) {

	//expect(recipeDataService.doSomething()).toEqual('something');

  }));

});