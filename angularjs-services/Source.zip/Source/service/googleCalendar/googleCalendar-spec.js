describe('googleCalendar', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(googleCalendar) {

	//expect(googleCalendar.doSomething()).toEqual('something');

  }));

});