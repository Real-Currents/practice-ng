describe('brewCalendar', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(brewCalendar) {

	//expect(brewCalendar.doSomething()).toEqual('something');

  }));

});