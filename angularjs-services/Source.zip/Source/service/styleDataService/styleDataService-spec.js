describe('styleDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(styleDataService) {

	//expect(styleDataService.doSomething()).toEqual('something');

  }));

});