describe('events', function() {


  beforeEach(module('brew-everywhere'));

  it('should ', inject(function(events) {

	//expect(events.doSomething()).toEqual('something');

  }));

});