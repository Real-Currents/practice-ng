describe('fermentableDataService', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(fermentableDataService) {

	//expect(fermentableDataService.doSomething()).toEqual('something');

  }));

});