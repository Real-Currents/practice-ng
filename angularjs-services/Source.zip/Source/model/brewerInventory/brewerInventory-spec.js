describe('brewerInventory', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(BrewerInventory) {

	//expect(brewerInventory.doSomething()).toEqual('something');

  }));

});