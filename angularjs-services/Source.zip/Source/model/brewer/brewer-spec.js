describe('brewer', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Brewer) {

	//expect(brewer.doSomething()).toEqual('something');

  }));

});