describe('mashProfile', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(MashProfile) {

	//expect(mashProfile.doSomething()).toEqual('something');

  }));

});