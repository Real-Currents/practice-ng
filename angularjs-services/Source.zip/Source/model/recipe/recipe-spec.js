describe('recipe', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Recipe) {

	//expect(recipe.doSomething()).toEqual('something');

  }));

});