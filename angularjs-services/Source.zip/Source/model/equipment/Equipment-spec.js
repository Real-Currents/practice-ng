describe('Equipment', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Equipment) {

	//expect(Equipment.doSomething()).toEqual('something');

  }));

});