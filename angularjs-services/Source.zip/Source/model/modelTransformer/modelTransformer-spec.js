describe('modelTransformer', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(modelTransformer) {

	//expect(modelTransformer.doSomething()).toEqual('something');

  }));

});