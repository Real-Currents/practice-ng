describe('mashStep', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(MashStep) {

	//expect(mashStep.doSomething()).toEqual('something');

  }));

});