describe('style', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Style) {

	//expect(style.doSomething()).toEqual('something');

  }));

});