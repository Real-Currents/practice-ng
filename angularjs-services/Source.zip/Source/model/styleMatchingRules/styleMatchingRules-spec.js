describe('styleMatchingRules', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(styleMatchingRules) {

	//expect(styleMatchingRules.doSomething()).toEqual('something');

  }));

});