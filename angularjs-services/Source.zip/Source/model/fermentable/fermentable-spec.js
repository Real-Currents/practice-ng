describe('fermentable', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Fermentable) {

	//expect(fermentable.doSomething()).toEqual('something');

  }));

});