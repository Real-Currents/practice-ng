describe('yeast', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Yeast) {

	//expect(yeast.doSomething()).toEqual('something');

  }));

});