describe('waterProfile', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(WaterProfile) {

	//expect(waterProfile.doSomething()).toEqual('something');

  }));

});