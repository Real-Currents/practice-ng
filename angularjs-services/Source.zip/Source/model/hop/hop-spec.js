describe('hop', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(Hop) {

	//expect(hop.doSomething()).toEqual('something');

  }));

});