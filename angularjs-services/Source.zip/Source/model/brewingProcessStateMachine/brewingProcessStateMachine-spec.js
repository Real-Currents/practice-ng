describe('brewingProcessStateMachine', function() {

  beforeEach(module('brew-everywhere'));

  it('should ...', inject(function(brewingProcessStateMachine) {

	//expect(brewingProcessStateMachine.doSomething()).toEqual('something');

  }));

});