angular.module('test.messaging', []).factory('messaging', function () {
  return {
    subscribe: function (topic, callback) {
    },
    publish: function (message, args) {
    },
    unsubscribe: function (handle) {
    }
  };
});

